#### Please follow the steps as blow:

* Import the **DocsBuilder-1.0.jar** to your project lib.
* Copy the **docs** folder to your project root folder.
* Then use the class **DocBuilder** to generate the api&vo docs.

#### Dependencies
```
	[                'commons-collections:commons-collections:3.2',
		    		 'commons-io:commons-io:2.4',
		    		 'freemarker:freemarker:2.3.9',
		    		 'commons-lang:commons-lang:2.6',
		    		 'org.codehaus.jackson:jackson-core-lgpl:1.9.8',
		    		 'org.codehaus.jackson:jackson-mapper-lgpl:1.9.8',
		    		 'servletapi:servletapi:2.4-20040521',
		    		 'org.springframework:spring-web:4.0.0.RELEASE',
					 'org.springframework:spring-jdbc:4.0.0.RELEASE',
					 'org.springframework:spring-orm:4.0.0.RELEASE',
					 'org.springframework:spring-tx:4.0.0.RELEASE',
					 'org.springframework:spring-test:4.0.0.RELEASE',
					 'org.springframework:spring-webmvc:4.0.0.RELEASE',
					 'org.commonjava.googlecode.markdown4j:markdown4j:2.2-cj-1.0',
					 'org.jsoup:jsoup:1.7.3',
					 'org.apache.struts:struts2-core:2.3.4'
			 ]
```

#### Execute

```
DocBuilder.buildDocs("org.zhubao.controller", "org.zhubao.vo", "config/init_gameserver_error_code.properties", System.getProperty("user.dir") +  "/docs/generated");


```