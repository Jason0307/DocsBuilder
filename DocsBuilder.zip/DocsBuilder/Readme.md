#### Please follow the steps as blow:

* Import the **DocsBuilder-1.0.jar** to your project lib.
* Copy the **docs** folder to your project root folder.
* Then use the class **DocBuilder** to generate the api&vo docs.
```
DocBuilder.buildDocs("org.zhubao.controller", "org.zhubao.vo", "config/init_gameserver_error_code.properties", System.getProperty("user.dir") +  "/docs/generated");


```